<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



//Route::get('/home', 'HomeController@index');

//==================== Login , Logout and Registration ======================

Route::get('/admin', 'LaravelController@admin');
Route::get('/registration', 'LaravelController@registration');
Route::post('/registrationsubmit', 'LaravelController@registrationsubmit');
Route::post('/adminlogin', 'LaravelController@adminlogin');
Route::get('/logout', 'LaravelController@logout');


//==================== After Login ======================

Route::group(['middleware' => ['auth']], function () {

	Route::get('/dashboard', 'LaravelController@dashboard');
	Route::get('/banner', 'LaravelController@banner');
	Route::get('/addbanner', 'LaravelController@addbanner');
	Route::post('/bannersubmit', 'LaravelController@bannersubmit');

	Route::get('/banneredit/{id}', 'LaravelController@banneredit');
	Route::post('/bannerupdate', 'LaravelController@bannerupdate');

});

Auth::routes();
