<footer class="footer text-right">
      2016 © Masud Rana (Laravel v5.3.16).
</footer>