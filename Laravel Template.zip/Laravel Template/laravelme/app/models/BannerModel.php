<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class BannerModel extends Model
{
    
    protected $table 			= "banner";
    protected $fillable 		= array('title','image','status');
}
