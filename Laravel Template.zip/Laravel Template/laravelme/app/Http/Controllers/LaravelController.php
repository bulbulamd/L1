<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

use App\models\LaravelModel;
use App\models\BannerModel;

use Auth;
use Validator;
use DB;

class LaravelController extends Controller
{
    

    function admin()
    {

    	return view('backend/login');
    }

    public function registration()
    {
    	return view('backend/register');
    }

    public function registrationsubmit(Request $request)
    {
    	
    	//dd($request->all());

    	// ==================== validation ==================

    	$this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
                //'admin' => 'required',
        ]);

    	$table 				= new LaravelModel();
    	$table->name 		= $request->get('name');
    	$table->email 		= $request->get('email');
    	$table->password 	= bcrypt($request->get('password'));
    	$table->save();

    	return redirect::to('/registration')->with('success', 'Your Data Insert Successfully');
    }

   
   public function adminlogin(Request $request)
    {
    	
        $this->validate($request, [
        	'email' 	=> 'required|email|max:255',
        	'password' 	=> 'required|min:6',

        ]);


        $email    = $request->get('email');
        $password = $request->get('password');

        if (Auth::attempt(['email' => $email, 'password' => $password])) 
        {
        	return redirect('dashboard');
        } 
        else
        {
            return redirect::to('/admin')->with('sorry', 'your email or password incorrect');
        }
    }


    public function dashboard()
    {
    	return view('backend/dashboard_middle');
    }


    //============================== BANNER ===========================

    public function banner()
    {
        $result = DB::table('banner')->get();
    	return view('backend/banner_page')->with('data', $result);;
    }

    public function addbanner()
    {
    	return view('backend/addbanner_page');
    }

   	public function bannersubmit(Request $request)
   	{
   		
   		//dd($request->all());

    	// ==================== validation ==================

    	$this->validate($request, [
            'title' => 'required | max:255',
            //'image' => 'required',
            'image' => 'required',
            //'image' => 'required | mimes:jpeg,jpg,png',
        ]);

    	$image 			= $request->file('image');
        $folder_location	= 'uploads/banner';
        $file_name_image 	= $image->getClientOriginalName();
        $success 		= $image->move($folder_location, $file_name_image);


    	$bannertable 		= new BannerModel();
    	$bannertable->title 	= $request->get('title');
    	$bannertable->image 	= $file_name_image;
    	$bannertable->status 	= $request->get('status');
    	$bannertable->save();

    	return redirect::to('/banner')->with('success', 'Successfully Added.');	

   	}

   	public function banneredit($id)
    {
        $result = DB::table('banner')->where('id',$id)->first();
        return view('backend/editbanner_page')->with('edit', $result);; 
    }


   	public function bannerupdate(Request $request)
   	{
   		
       $input = $request->except('_token');
            
        //dd($request);
       if ($input) 
       {

            $update_govt = BannerModel::findorfail($request->get('id'));
            $update_govt->update($input);

            //return redirect::to('/banner')->with('success', 'Update Successfully Done.');   

           $file = $request->file('image');

           if (!empty($file)) 
           {
                 //dd($file);

               $validator = Validator::make($request->all(), [
                           'image' => 'required',
               ]);

               if ($validator->fails()) 
               {
                   //dd($file);
                   return redirect::to('editbanner/' . $request->get('id'))->withErrors($validator);
               }
               else
               {
                   //dd($file);

                    $image              = $request->file('image');
                    $folder_location    = 'uploads/banner';
                    $file_name_image    = $image->getClientOriginalName();
                    $success            = $image->move($folder_location, $file_name_image);

                    $update_govt        = BannerModel::where('id', '=', $request->get('id'));
                    $update_govt->update(['image' => $file_name_image]);

                    return redirect::to('/banner')->with('success', 'Update Successfully Done.');   
               }
            }
            else
            {
                return redirect::to('/banner')->with('success', 'Update Successfully Done.');   
            }  
        }
   	}


   //  public function update_govt_job(request $request, $id) {

   //     $input = $request->except('_token');
   //     $update_govt = GovnJobsModel::where('govn_id', '=', $id);


   //     $data = $update_govt->update($input);


   //     if ($data) {
   //         $file = $request->file('logo_name');

   //         if (!empty($file)) {
   //             $validator = Validator::make($request->all(), [
   //                         'logo_name' => 'required|mimes:jpg,jpeg,png|max:1000kb',
   //             ]);
   //             if ($validator->fails()) {
   //                 return redirect::to('edit-govt_job/' . $id)->withErrors($validator);
   //             } else {
   //                 $logo = $request->file('logo_name');
   //                 $fath = 'uploads/logo';
   //                 $file_name = $logo->getClientOriginalName();
   //                 $success = $logo->move($fath, $file_name);
   //                 $update_govt = GovnJobsModel::where('govn_id', '=', $id);
   //                 $update_govt->update(['logo_name' => $file_name]);
   //             }
   //         }
   //     }
   //     return redirect::to('govt-job-manage')->with('success', 'your data update successfully');
   // }



    ////////// Logout
    public function logout()
    {
    	auth::logout();
    	return redirect::to('/admin')->with('sorry', 'Successfully logout.');

    }


}
